// Backend starter code for EmporiGlobe app
