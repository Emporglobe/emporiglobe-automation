// Frontend dashboard entry point
